# OZHINSKAYA на Ozon: разбор отзывов

Одностраничный отчёт WOS VoC (HTML, без сборки). Откройте `index.html` в браузере или подключите GitHub Pages.
